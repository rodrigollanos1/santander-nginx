# Usage

You need to populate the container with custom NginX configuration files:
```
/etc/nginx/nginx.conf
/etc/nginx/conf.d/default.conf
```
